<?php
defined('_JEXEC') or die;

class BplpController extends JControllerLegacy
{
}