<?php
defined('_JEXEC') or die;

class BplpControllerLivres extends JControllerForm
{
}